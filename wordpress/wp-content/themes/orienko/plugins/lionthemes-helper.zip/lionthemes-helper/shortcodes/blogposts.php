<?php
function orienko_blogposts_shortcode( $atts ) {
	global $orienko_opt;
	$post_index = 0;
	$atts = shortcode_atts( array(
		'title' => '',
		'show_icon'=>'',
		'icon'=>'',
		'number' => 5,
		'order' => 'DESC',
		'orderby' => 'post_date',
		'image' => 'wide', //square
		'length' => 20,
		'style' => 'carousel',
		'content_style' => '',
		'columns' => '1',
		'showon_effect' => '',
		'rows' => '1',
		'desksmall' => '4',
		'tablet_count' => '3',
		'tabletsmall' => '2',
		'mobile_count' => '1',
		'margin' => '0'
	), $atts, 'blogposts' );
	extract($atts);
	if($image == 'wide'){
		$imagesize = 'orienko-post-thumbwide';
	} else {
		$imagesize = 'orienko-post-thumb';
	}
	$html = '';

	$postargs = array(
		'posts_per_page'   => $number,
		'offset'           => 0,
		'category'         => '',
		'category_name'    => '',
		'orderby'          => $orderby,
		'order'            => $order,
		'include'          => '',
		'exclude'          => '',
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => 'post',
		'post_mime_type'   => '',
		'post_parent'      => '',
		'post_status'      => 'publish',
		'suppress_filters' => true );
	$postslist = get_posts( $postargs );
	$total = count($postslist);
	if($total == 0) return;
	switch ($columns) {
		case '6':
			$class_column='col-lg-2 col-md-3 col-sm-4 col-xs-12';
			break;
		case '5':
			$class_column='col-lg-20 col-md-3 col-sm-4 col-xs-12';
			break;
		case '4':
			$class_column='col-lg-3 col-md-4 col-sm-6 col-xs-12';
			break;
		case '3':
			$class_column='col-md-4 col-sm-6 col-xs-12';
			break;
		case '2':
			$class_column='col-md-6 col-sm-6 col-xs-12';
			break;
		default:
			$class_column='col-md-3 col-sm-6 col-xs-12';
			break;
	}
	$row_cl = ' row';
	if($style != 'grid'){
		$row_cl = $class_column = '';
	}
	$before_title = $after_title = '';
	if($show_icon && $icon){
		$before_title = '<i class="' . esc_attr($icon) . '"></i>';
	}
	$showon_effect = ($showon_effect) ? ' wow ' . $showon_effect : '';
	$html.='<div class="blog-posts'. (($content_style) ? ' ' . $content_style : '') . esc_attr($row_cl) .'">';
		$html .= ($title) ? '<h3 class="vc_widget_title vc_blog_title">'. $before_title .'<span>'. esc_html($title) .'</span></h3>' : '';
			$html .= ($style == 'carousel') ? '<div class="owl-carousel owl-theme" data-desksmall="'. esc_attr($desksmall) .'" data-tabletsmall="'. esc_attr($tabletsmall) .'" data-mobile="'. esc_attr($mobile_count) .'" data-tablet="'. esc_attr($tablet_count) .'" data-margin="'. intval($margin) .'" data-dots="false" data-nav="true" data-owl="slide" data-item-slide="'. esc_attr($columns) .'" data-ow-rtl="false">':'';
			$duration = 0;
			foreach ( $postslist as $post ) {
				$duration = $duration + 100;
				if($rows > 1 && $style == 'carousel'){
					$post_index ++;
					if ( (( $post_index - 1 ) % $rows == 0) && $post_index < $total){
						$html .= '<div class="group">';
					}
				}
				$class_nothumb = '';
				if(!get_the_post_thumbnail( $post->ID, $imagesize )) $class_nothumb = ' no-thumb';
				$html.='<div class="item-post post-'. $post->ID .' ' . $class_column . $class_nothumb . $showon_effect .'" data-wow-delay="'. $duration .'ms" data-wow-duration="0.5s">';
					$html.='<div class="post-wrapper">';
						
						$html.='<div class="post-thumb">';
							if(get_the_post_thumbnail( $post->ID, $imagesize )){
								$html.='<a href="'.get_the_permalink($post->ID).'">'.get_the_post_thumbnail($post->ID, $imagesize).'</a>';
							}
							$html.='<div class="blogdate orienko-widget-date">
										<div>
											<span class="day">'. get_the_date('d', $post->ID) . '</span>
											<span class="month">'. get_the_date('M', $post->ID). '</span>
										</div>
									</div>';
						$html.='</div>';
						
						$html.='<div class="post-info">';
							$html.='<h3 class="post-title"><a href="'.get_the_permalink($post->ID).'">'.get_the_title($post->ID).'</a></h3>';		
							$html.='<div class="post-excerpt">';
								$html.= lionthemes_get_excerpt($post->ID, $length);
							$html.='</div>';
							$html.= '<a href="'. get_the_permalink($post->ID) .'"><span class="readmore-text">'. esc_html__('Read More', 'orienko') .'</span></a>';
						$html.='</div>';

					$html.='</div>';
				$html.='</div>';
				if($rows > 1 && $style == 'carousel'){
					if (($post_index % $rows == 0) || $post_index == $total ) {
						$html .= '</div>';
					}
				}
			}
		$html .= ($style == 'carousel') ? '</div>':'';
	$html.='</div>';

	wp_reset_postdata();
	
	return $html;
}
add_shortcode( 'blogposts', 'orienko_blogposts_shortcode' );
?>