<?php 

// Import slider, setup menu locations, setup home page
function lionthemes_helper_wbc_extended_example( $demo_active_import , $demo_directory_path ) {

	reset( $demo_active_import );
	$current_key = key( $demo_active_import );

	// Revolution Slider import all
	if ( class_exists( 'RevSlider' ) ) {
		$wbc_sliders_array = array(
			'Orienko' => array('home-slider-shop-1.zip', 'home-slider-shop-2.zip', 'home-slider-shop-3.zip'),
		);

		if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
			$wbc_slider_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
			foreach($wbc_slider_import as $file_backup){
				if ( file_exists( $demo_directory_path . $file_backup ) ) {
					$slider = new RevSlider();
					$slider->importSliderFromPost( true, true, $demo_directory_path . $file_backup );
				}
			}
		}
	}
	// menu localtion settings
	$primary_menu = get_term_by( 'name', 'Main menu', 'nav_menu' );
	$cat_menu = get_term_by( 'name', 'Categories', 'nav_menu' );

	if ( isset( $primary_menu->term_id ) && isset( $cat_menu->term_id )) {
		set_theme_mod( 'nav_menu_locations', array(
				'primary' => $primary_menu->term_id,
				'mobilemenu'  => $primary_menu->term_id,
				'categories' => $cat_menu->term_id
			)
		);
	}
	
	// megamenu options
	global $mega_main_menu;
	
	$exported_file = $demo_directory_path . 'mega-main-menu-settings.json';
	
	if ( file_exists( $exported_file ) ) {
		$backup_file_content = file_get_contents ( $exported_file );
		
		if ( $backup_file_content !== false && ( $options_backup = json_decode( $backup_file_content, true ) ) ) {
			update_option( $mega_main_menu->constant[ 'MM_OPTIONS_NAME' ], $options_backup );
		}
	}

	// Home page setup default
	$page_options = array(
		'page_on_front' => 'Home Shop 1',
		'page_for_posts' => 'Blog',
		'projects_page_id' => 'Portfolio',
		'yith_wcwl_wishlist_page_id' => 'Wishlist',
		'woocommerce_shop_page_id' => 'Shop',
		'woocommerce_cart_page_id' => 'Cart',
		'woocommerce_checkout_page_id' => 'Checkout',
		'woocommerce_myaccount_page_id' => 'My Account',
	);
	
	foreach ( $page_options as $key => $page_title ) {
		$page = get_page_by_title( $page_title );
		if ( isset( $page->ID ) ) {
			if ($key == 'projects_page_id') {
				update_option( 'projects-pages-fields', array( $key => $page->ID ));
			} else {
				update_option( $key, $page->ID );
			}
		}
	}
	
	$project_imgs = array(
		'project-archive' => array('width' => 600, 'height' => 600, 'crop' => 'yes'),
		'project-single' => array('width' => 1024, 'height' => 1024, 'crop' => 'yes'),
		'project-thumbnail' => array('width' => 100, 'height' => 100, 'crop' => 'yes'),
	);
	update_option( 'woocommerce_single_image_width', 600 );
	update_option( 'woocommerce_thumbnail_image_width', 300 );
	update_option( 'woocommerce_thumbnail_cropping', 'custom' );
	update_option( 'woocommerce_thumbnail_cropping_custom_width', 281 );
	update_option( 'woocommerce_thumbnail_cropping_custom_height', 207 );
	update_option( 'projects-images-fields', $project_imgs );
	update_option( 'show_on_front', 'page' );
	update_option( 'yith_wcmg_lens_opacity', 0.5 );
	update_option( 'yith_woocompare_compare_button_in_products_list', 'no' );
	update_option( 'permalink_structure', '/%postname%/' );
	update_option( 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:8:"/product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}' );
	update_option( 'mc4wp_default_form_id', 1402 );
}
add_action( 'wbc_importer_after_content_import', 'lionthemes_helper_wbc_extended_example', 10, 2 );


function lionthemes_helper_update_extra_menu_meta($item, $id) {
	$only_update = array('mmm_submenu_type', 'mmm_submenu_columns', 'mmm_item_icon', 'mmm_item_descr');
	if (!empty($item['postmeta'])) {
		foreach($item['postmeta'] as $meta) {
			if (in_array($meta['key'], $only_update) && $meta['value']) {
				$value = strval($meta['value']);
				if (is_serialized($meta['value'])) {
					$value = unserialize($meta['value']);
				}
				if ($value && is_string($value) && strpos($value, LION_CURRENT_THEME)) {
					$sub_start = strpos($value, LION_CURRENT_THEME) + strlen(LION_CURRENT_THEME);
					$value = get_site_url() . substr($value, $sub_start, strlen($value));
				}
				update_post_meta( $id, $meta['key'], $value);
			}
		}
	}
}
add_action( 'wordpress_importer_after_import_menu_item', 'lionthemes_helper_update_extra_menu_meta', 10, 2);


add_action('radium_theme_import_widget_after_import', 'lionthemes_reset_widget_options_after_import');
add_action('wbc_after_update_widget_options', 'lionthemes_reset_widget_options_after_import');
function lionthemes_reset_widget_options_after_import() {
	$footer_menus = array(
		'footer_4columns' => array('Information', 'My Account', 'Our Services'),
	);
	$widget_sidebars = array(
		'top_header' => array('text'),
		'blog' => array('search', 'categories', 'orienko_recent_comment', 'orienko_recent_post', 'archives', 'meta'),
		'shop' => array('woocommerce_product_categories', 'woocommerce_price_filter', 'woocommerce_layered_nav', 'yith-woocompare-widget', 'woocommerce_product_tag_cloud', 'woocommerce_products'),
		'footer_newsletter' => array('mc4wp_form_widget'),
		'footer_4columns' => array('nav_menu', 'text'),
		'footer_payment' => array('text'),
		'footer_copyright' => array('text'),
	);
	$sidebars_widgets = get_option( 'sidebars_widgets' );
	$widget_nav_menu = get_option( 'widget_nav_menu' );
	$update_menu_ids = array();
	$sidebars_widgets['wp_inactive_widgets'] = array();
	foreach($widget_sidebars as $area => $widget_keys) {
		if (!empty($sidebars_widgets[$area])) {
			foreach($sidebars_widgets[$area] as $key => $widget) {
				$widget_detail = explode('-', $widget);
				$widget_position = $widget_detail[count($widget_detail) - 1];
				$widget_key = str_replace('-' . $widget_position, '', $widget);
				if(!in_array($widget_key, $widget_keys)) unset($sidebars_widgets[$area][$key]);
				if (in_array($widget_key, $widget_keys) && $widget_key == 'nav_menu') {
					$update_menu_ids[$area][] = $widget_position;
				}
			}
		}
	}
	if(!empty($update_menu_ids)) {
		foreach($update_menu_ids as $area => $positions) {
			foreach($positions as $key => $pos) {
				if(!empty($footer_menus[$area][$key]) && !empty($widget_nav_menu[$pos])) {
					$menu_name = $footer_menus[$area][$key];
					$menu = get_term_by( 'name', $menu_name, 'nav_menu' );
					if (!empty( $menu->term_id )) {
						$widget_nav_menu[$pos]['title'] = $menu_name;
						$widget_nav_menu[$pos]['nav_menu'] = $menu->term_id;
					}
				}
			}
		}
	}
	update_option( 'sidebars_widgets', $sidebars_widgets );
	update_option( 'widget_nav_menu', $widget_nav_menu );
}

add_action('import_start', 'lionthemes_before_start_import_dummy');
function lionthemes_before_start_import_dummy() {
	$default_posts = array('Shop', 'My account', 'Cart', 'Checkout','Hello world!', 'Sample Page', 'Wishlist');
	foreach($default_posts as $page) {
		if ($post_id = post_exists( $page )) {
			wp_delete_post($post_id, true);
		}
	}
}